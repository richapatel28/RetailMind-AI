from pydantic import BaseModel


class ProductMatchRequest(BaseModel):

    product_name: str