from pydantic import BaseModel

from typing import (
    Optional,
    List
)


class ReconciliationRequest(BaseModel):

    transaction_date: str

    amount: float

    reference: Optional[str] = None

    narration: Optional[str] = None

    direction: str


class ReconciliationResponse(BaseModel):

    transaction: ReconciliationRequest

    candidates: List[dict]

    best_match: Optional[dict] = None

    confidence: float = 0.0

    status: str