from datetime import datetime
from decimal import Decimal

from rapidfuzz.fuzz import ratio

from app.config.database import get_connection


# ======================================================
# CONFIGURATION
# ======================================================

AMOUNT_WEIGHT = 0.45
REFERENCE_WEIGHT = 0.30
PARTY_WEIGHT = 0.10
DATE_WEIGHT = 0.15

MATCH_THRESHOLD = 0.85
REVIEW_THRESHOLD = 0.60

TOP_CANDIDATES = 5


# ======================================================
# TEXT NORMALIZATION
# ======================================================

def normalize_text(value):

    if not value:
        return ""

    value = str(value).lower().strip()

    value = "".join(
        char if char.isalnum() else " "
        for char in value
    )

    value = " ".join(value.split())

    return value


# ======================================================
# TEXT SIMILARITY
# ======================================================

def text_score(value1, value2):

    value1 = normalize_text(value1)
    value2 = normalize_text(value2)

    if not value1 or not value2:
        return 0.0

    if value1 == value2:
        return 1.0

    return ratio(value1, value2) / 100.0


# ======================================================
# AMOUNT SCORE
# ======================================================

def amount_score(statement_amount, record_amount):

    statement_amount = Decimal(
        str(statement_amount)
    )

    record_amount = Decimal(
        str(record_amount)
    )

    if statement_amount == record_amount:
        return 1.0

    difference = abs(
        statement_amount - record_amount
    )

    if difference <= Decimal("1"):
        return 0.90

    if difference <= Decimal("5"):
        return 0.70

    if difference <= Decimal("10"):
        return 0.40

    return 0.0


# ======================================================
# DATE SCORE
# ======================================================

def date_score(statement_date, record_date):

    try:

        statement_dt = datetime.strptime(
            statement_date,
            "%Y-%m-%d"
        ).date()

        if isinstance(record_date, datetime):
            record_dt = record_date.date()
        else:
            record_dt = record_date

        difference = abs(
            (statement_dt - record_dt).days
        )

        if difference == 0:
            return 1.0

        if difference == 1:
            return 0.90

        if difference == 2:
            return 0.75

        if difference == 3:
            return 0.60

        return 0.0

    except Exception:
        return 0.0


# ======================================================
# STATUS
# ======================================================

def get_status(confidence):

    if confidence >= MATCH_THRESHOLD:
        return "MATCHED"

    if confidence >= REVIEW_THRESHOLD:
        return "REVIEW_REQUIRED"

    return "UNMATCHED"


# ======================================================
# CREDIT MATCHING
# Customer → Shop
# ======================================================

def match_credit_transaction(
    cursor,
    user_id,
    transaction_date,
    amount,
    reference,
    narration
):

    cursor.execute(
        """
        SELECT
            p.id,
            p.sale_id,
            p.customer_id,
            p.amount,
            p.mode,
            p.reference,
            p.payment_date,
            c.name AS customer_name
        FROM payments p
        JOIN sales s
            ON p.sale_id = s.id
        LEFT JOIN customers c
            ON p.customer_id = c.id
        WHERE p.user_id = %s
          AND s.user_id = %s
          AND UPPER(p.status) IN (
              'COMPLETED',
              'PAID',
              'CONFIRMED'
          )
          AND UPPER(p.mode) IN (
              'UPI',
              'BANK_TRANSFER',
              'BANK',
              'CARD',
              'ONLINE',
              'NEFT',
              'RTGS',
              'IMPS'
          )
        ORDER BY p.payment_date DESC
        """,
        (
            user_id,
            user_id
        )
    )

    payments = cursor.fetchall()

    candidates = []

    for payment in payments:

        (
            payment_id,
            sale_id,
            customer_id,
            payment_amount,
            mode,
            payment_reference,
            payment_date,
            customer_name
        ) = payment

        amount_similarity = amount_score(
            amount,
            payment_amount
        )

        reference_similarity = text_score(
            reference,
            payment_reference
        )

        party_similarity = text_score(
            narration,
            customer_name
        )

        date_similarity = date_score(
            transaction_date,
            payment_date
        )

        confidence = (
            amount_similarity * AMOUNT_WEIGHT
            + reference_similarity * REFERENCE_WEIGHT
            + party_similarity * PARTY_WEIGHT
            + date_similarity * DATE_WEIGHT
        )

        confidence = round(
            confidence,
            4
        )

        candidates.append({

            "transaction_type": "CUSTOMER_PAYMENT",

            "payment_id": payment_id,

            "sale_id": sale_id,

            "customer_id": customer_id,

            "customer_name": customer_name,

            "amount": float(payment_amount),

            "mode": mode,

            "reference": payment_reference,

            "payment_date":
                payment_date.isoformat()
                if payment_date
                else None,

            "amount_score":
                round(amount_similarity, 4),

            "reference_score":
                round(reference_similarity, 4),

            "party_score":
                round(party_similarity, 4),

            "date_score":
                round(date_similarity, 4),

            "confidence":
                confidence,

            "status":
                get_status(confidence)
        })


    return candidates


# ======================================================
# DEBIT MATCHING
# Shop → Supplier
# ======================================================

def match_debit_transaction(
    cursor,
    user_id,
    transaction_date,
    amount,
    reference,
    narration
):

    cursor.execute(
        """
        SELECT
            sp.id,
            sp.purchase_id,
            sp.supplier_id,
            sp.amount,
            sp.mode,
            sp.reference,
            sp.payment_date,
            s.name AS supplier_name,
            p.invoice_no,
            p.total_amount AS purchase_amount,
            p.purchase_date
        FROM supplier_payments sp
        JOIN purchases p
            ON sp.purchase_id = p.id
        LEFT JOIN suppliers s
            ON sp.supplier_id = s.id
        WHERE sp.user_id = %s
          AND p.user_id = %s
          AND UPPER(sp.status) IN (
              'COMPLETED',
              'PAID',
              'CONFIRMED'
          )
          AND UPPER(sp.mode) IN (
              'UPI',
              'BANK_TRANSFER',
              'BANK',
              'CARD',
              'ONLINE',
              'NEFT',
              'RTGS',
              'IMPS'
          )
        ORDER BY sp.payment_date DESC
        """,
        (
            user_id,
            user_id
        )
    )

    supplier_payments = cursor.fetchall()

    candidates = []

    for payment in supplier_payments:

        (
            supplier_payment_id,
            purchase_id,
            supplier_id,
            payment_amount,
            mode,
            payment_reference,
            payment_date,
            supplier_name,
            invoice_no,
            purchase_amount,
            purchase_date
        ) = payment


        amount_similarity = amount_score(
            amount,
            payment_amount
        )


        reference_similarity = text_score(
            reference,
            payment_reference
        )


        # Also compare narration against supplier name
        party_similarity = text_score(
            narration,
            supplier_name
        )


        date_similarity = date_score(
            transaction_date,
            payment_date
        )


        confidence = (
            amount_similarity * AMOUNT_WEIGHT
            + reference_similarity * REFERENCE_WEIGHT
            + party_similarity * PARTY_WEIGHT
            + date_similarity * DATE_WEIGHT
        )


        confidence = round(
            confidence,
            4
        )


        candidates.append({

            "transaction_type": "SUPPLIER_PAYMENT",

            "supplier_payment_id":
                supplier_payment_id,

            "purchase_id":
                purchase_id,

            "supplier_id":
                supplier_id,

            "supplier_name":
                supplier_name,

            "invoice_no":
                invoice_no,

            "amount":
                float(payment_amount),

            "mode":
                mode,

            "reference":
                payment_reference,

            "payment_date":
                payment_date.isoformat()
                if payment_date
                else None,

            "purchase_amount":
                float(purchase_amount)
                if purchase_amount is not None
                else None,

            "amount_score":
                round(amount_similarity, 4),

            "reference_score":
                round(reference_similarity, 4),

            "party_score":
                round(party_similarity, 4),

            "date_score":
                round(date_similarity, 4),

            "confidence":
                confidence,

            "status":
                get_status(confidence)
        })


    return candidates


# ======================================================
# MAIN RECONCILIATION FUNCTION
# ======================================================

def reconcile_transaction(
    user_id,
    transaction_date,
    amount,
    reference=None,
    narration=None,
    direction="CREDIT"
):

    direction = direction.upper().strip()

    if direction not in (
        "CREDIT",
        "DEBIT"
    ):

        return {
            "status": "UNMATCHED",
            "candidates": [],
            "best_match": None
        }


    connection = get_connection()

    try:

        cursor = connection.cursor()


        # ==================================================
        # CREDIT
        # ==================================================

        if direction == "CREDIT":

            candidates = match_credit_transaction(
                cursor,
                user_id,
                transaction_date,
                amount,
                reference,
                narration
            )


        # ==================================================
        # DEBIT
        # ==================================================

        else:

            candidates = match_debit_transaction(
                cursor,
                user_id,
                transaction_date,
                amount,
                reference,
                narration
            )


        # ==================================================
        # Sort by confidence
        # ==================================================

        candidates.sort(
            key=lambda item:
                item["confidence"],
            reverse=True
        )


        candidates = candidates[
            :TOP_CANDIDATES
        ]


        # ==================================================
        # Determine best match
        # ==================================================

        best_match = None


        if candidates:

            top = candidates[0]


            if len(candidates) > 1:

                second = candidates[1]


                confidence_gap = (
                    top["confidence"]
                    - second["confidence"]
                )


                # Don't automatically select
                # an ambiguous candidate.

                if (
                    top["confidence"]
                    >= MATCH_THRESHOLD
                    and confidence_gap >= 0.10
                ):

                    best_match = top

                elif (
                    top["confidence"]
                    >= REVIEW_THRESHOLD
                ):

                    best_match = top


            elif (
                top["confidence"]
                >= REVIEW_THRESHOLD
            ):

                best_match = top


        # ==================================================
        # Overall status
        # ==================================================

        if best_match:

            overall_status = (
                best_match["status"]
            )

        else:

            overall_status = "UNMATCHED"

            if candidates:

                if (
                    candidates[0]["confidence"]
                    >= REVIEW_THRESHOLD
                ):

                    overall_status = (
                        "REVIEW_REQUIRED"
                    )


        return {

            "status":
                overall_status,

            "candidates":
                candidates,

            "best_match":
                best_match
        }


    finally:

        connection.close()