import React from "react";
import { CheckCircle2, AlertCircle, HelpCircle, Clock, XCircle, Sparkles } from "lucide-react";

export const StatusBadge = ({ status, size = "sm" }) => {
  if (!status) return null;

  const normalized = String(status).toUpperCase();

  const configs = {
    MATCHED: {
      label: "Matched",
      bg: "bg-emerald-50 text-emerald-700 border-emerald-200",
      icon: CheckCircle2,
    },
    PROCESSED: {
      label: "Processed",
      bg: "bg-blue-50 text-blue-700 border-blue-200",
      icon: Sparkles,
    },
    REVIEW_REQUIRED: {
      label: "Review Required",
      bg: "bg-amber-50 text-amber-700 border-amber-200",
      icon: AlertCircle,
    },
    REVIEW: {
      label: "Review",
      bg: "bg-amber-50 text-amber-700 border-amber-200",
      icon: AlertCircle,
    },
    UNMATCHED: {
      label: "Unmatched",
      bg: "bg-rose-50 text-rose-700 border-rose-200",
      icon: HelpCircle,
    },
    PAID: {
      label: "Paid",
      bg: "bg-emerald-50 text-emerald-700 border-emerald-200",
      icon: CheckCircle2,
    },
    PARTIAL: {
      label: "Partial",
      bg: "bg-amber-50 text-amber-700 border-amber-200",
      icon: Clock,
    },
    PENDING: {
      label: "Pending",
      bg: "bg-slate-100 text-slate-700 border-slate-200",
      icon: Clock,
    },
    CREDIT: {
      label: "Credit",
      bg: "bg-purple-50 text-purple-700 border-purple-200",
      icon: AlertCircle,
    },
    CONFIRMED: {
      label: "Confirmed",
      bg: "bg-emerald-50 text-emerald-700 border-emerald-200",
      icon: CheckCircle2,
    },
    ERROR: {
      label: "Error",
      bg: "bg-rose-50 text-rose-700 border-rose-200",
      icon: XCircle,
    },
  };

  const current = configs[normalized] || {
    label: status,
    bg: "bg-slate-100 text-slate-700 border-slate-200",
    icon: Sparkles,
  };

  const Icon = current.icon;
  const sizeClasses = size === "xs" ? "text-[11px] px-1.5 py-0.5" : "text-xs px-2.5 py-1";

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-medium rounded-full border ${current.bg} ${sizeClasses}`}
    >
      <Icon className="w-3.5 h-3.5 flex-shrink-0" />
      <span>{current.label}</span>
    </span>
  );
};

export default StatusBadge;
