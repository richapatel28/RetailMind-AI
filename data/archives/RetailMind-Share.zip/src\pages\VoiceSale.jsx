import React, { useState, useRef, useEffect } from "react";
import {
  Mic,
  Square,
  Upload,
  Sparkles,
  CheckCircle2,
  RefreshCw,
  AlertCircle,
  FileAudio,
  ArrowRight,
  ShieldCheck,
  Edit3,
  Globe
} from "lucide-react";
import { processVoiceAudio, processVoiceText, confirmVoiceSale } from "../services/voiceApi";
import { getProducts } from "../services/productApi";
import StatusBadge from "../components/StatusBadge";
import ConfidenceMeter from "../components/ConfidenceMeter";
import { useToast } from "../components/Toast";

export const VoiceSale = () => {
  const { addToast } = useToast();

  // Voice Language: English or Hindi
  const [voiceLanguage, setVoiceLanguage] = useState("en");

  // Recording & Upload States
  const [recording, setRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);

  // Text Phrase Fallback / Testing State
  const [phraseInput, setPhraseInput] = useState("");
  const [isEditingTranscript, setIsEditingTranscript] = useState(false);
  const [editedTranscript, setEditedTranscript] = useState("");

  // Result & Review States
  const [result, setResult] = useState(null);
  const [products, setProducts] = useState([]);
  const [manualEditMode, setManualEditMode] = useState(false);

  // Editable Form Fields for Confirmation (No fake defaults)
  const [selectedProductId, setSelectedProductId] = useState("");
  const [quantity, setQuantity] = useState("");
  const [unitPrice, setUnitPrice] = useState("");
  const [paymentMode, setPaymentMode] = useState("CASH");
  const [paymentAmount, setPaymentAmount] = useState("");

  // Confirmation State
  const [confirming, setConfirming] = useState(false);
  const [confirmedSale, setConfirmedSale] = useState(null);
  const [error, setError] = useState(null);

  // MediaRecorder refs
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const timerRef = useRef(null);
  const fileInputRef = useRef(null);

  // Fetch product catalog for selection dropdown
  useEffect(() => {
    getProducts()
      .then((data) => setProducts(Array.isArray(data) ? data : []))
      .catch((err) => console.error("Failed to load products:", err));
  }, []);

  // Timer for audio recording
  useEffect(() => {
    if (recording) {
      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } else {
      clearInterval(timerRef.current);
      setRecordingDuration(0);
    }
    return () => clearInterval(timerRef.current);
  }, [recording]);

  // Start live microphone recording
  const startRecording = async () => {
    setError(null);
    setConfirmedSale(null);
    setResult(null);
    setSelectedFile(null);
    setAudioBlob(null);
    setSelectedProductId("");
    setQuantity("");
    setUnitPrice("");
    setPaymentAmount("");
    setManualEditMode(false);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        setAudioBlob(blob);
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setRecording(true);
    } catch (err) {
      console.error("Microphone error:", err);
      setError("Microphone access denied or not supported. Please upload an audio file instead.");
    }
  };

  // Stop live microphone recording
  const stopRecording = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      setRecording(false);
    }
  };

  // Handle local audio file selection
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedFile(file);
      setAudioBlob(null);
      setError(null);
      setConfirmedSale(null);
      setResult(null);
      setSelectedProductId("");
      setQuantity("");
      setUnitPrice("");
      setPaymentAmount("");
      setManualEditMode(false);
    }
  };

  const populateResultData = (data) => {
    setResult(data);

    const matched = data.product_match?.matched_product;
    const hasProduct = Boolean(matched && matched.id);
    const hasQuantity = Boolean(data.quantity && Number(data.quantity) > 0);

    // Populate matched product ID
    setSelectedProductId(hasProduct ? String(matched.id) : "");

    // Populate quantity only if detected (NEVER default to 1)
    const detectedQty = hasQuantity ? Number(data.quantity) : "";
    setQuantity(detectedQty);

    // Determine unit selling price
    let detectedPrice = "";
    if (data.unit_price) {
      detectedPrice = Number(data.unit_price);
    } else if (data.amount && detectedQty) {
      detectedPrice = Number((Number(data.amount) / Number(detectedQty)).toFixed(2));
    } else if (hasProduct && matched.selling_price) {
      detectedPrice = Number(matched.selling_price);
    }
    setUnitPrice(detectedPrice);

    // Determine total payment amount
    let detectedAmount = "";
    if (data.amount) {
      detectedAmount = Number(data.amount);
    } else if (detectedQty && detectedPrice) {
      detectedAmount = Number((Number(detectedQty) * Number(detectedPrice)).toFixed(2));
    }
    setPaymentAmount(detectedAmount);

    const mode = (data.payment_mode || "CASH").toUpperCase();
    setPaymentMode(["CASH", "UPI", "CREDIT"].includes(mode) ? mode : "CASH");
    setManualEditMode(false);
    setIsEditingTranscript(false);

    if (hasProduct && hasQuantity) {
      addToast("Voice sale recognized! Review and confirm below.", "success");
    } else {
      addToast("Voice processed. Review required.", "warning");
    }
  };

  // Process the recorded audio or uploaded file
  const handleProcessAudio = async (overrideFile = null) => {
    const fileToProcess = overrideFile || selectedFile || audioBlob;
    if (!fileToProcess) {
      setError("Please record audio or upload an audio file first.");
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      const data = await processVoiceAudio(fileToProcess, voiceLanguage);
      populateResultData(data);
    } catch (err) {
      console.error("Voice process error:", err);
      setError(err.response?.data?.message || "Failed to process audio. Please try again.");
      addToast("Voice processing failed.", "error");
    } finally {
      setProcessing(false);
    }
  };

  // Process typed speech phrase directly (testing or manual transcript edit)
  const handleProcessText = async (textOverride = null) => {
    const textToProcess = textOverride || phraseInput;
    if (!textToProcess || !textToProcess.trim()) {
      setError("Please enter a speech phrase to analyze.");
      return;
    }

    setProcessing(true);
    setError(null);

    try {
      const data = await processVoiceText(textToProcess.trim(), voiceLanguage);
      populateResultData(data);
    } catch (err) {
      console.error("Voice text process error:", err);
      setError(err.response?.data?.message || "Failed to analyze speech text. Please try again.");
      addToast("Voice analysis failed.", "error");
    } finally {
      setProcessing(false);
    }
  };

  // Confirm Sale Transaction
  const handleConfirmSale = async () => {
    if (!result?.event_id) {
      setError("No active voice event to confirm.");
      return;
    }

    if (!selectedProductId) {
      setError("Please select a product from inventory.");
      return;
    }

    if (!quantity || Number(quantity) <= 0) {
      setError("Quantity must be greater than 0.");
      return;
    }

    if (!paymentAmount || Number(paymentAmount) <= 0) {
      setError("Payment amount must be greater than 0.");
      return;
    }

    setConfirming(true);
    setError(null);

    try {
      const payload = {
        event_id: result.event_id,
        items: [
          {
            product_id: Number(selectedProductId),
            quantity: Number(quantity),
            selling_price: Number(unitPrice || 0),
          },
        ],
        payment_mode: paymentMode,
        payment_amount: Number(paymentAmount),
      };

      const confirmation = await confirmVoiceSale(payload);
      setConfirmedSale(confirmation);
      addToast(`Sale #${confirmation.sale_id} confirmed and recorded into PostgreSQL!`, "success");

      // Refresh product list to show updated stock
      getProducts().then((data) => setProducts(Array.isArray(data) ? data : []));
    } catch (err) {
      console.error("Voice confirm error:", err);
      setError(err.response?.data?.message || "Failed to confirm sale transaction.");
      addToast("Sale confirmation failed.", "error");
    } finally {
      setConfirming(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setAudioBlob(null);
    setSelectedFile(null);
    setConfirmedSale(null);
    setError(null);
    setSelectedProductId("");
    setQuantity("");
    setUnitPrice("");
    setPaymentAmount("");
    setPaymentMode("CASH");
    setManualEditMode(false);
    setPhraseInput("");
    setIsEditingTranscript(false);
    setEditedTranscript("");
  };

  // Product selection handler that auto-fills catalog selling price
  const handleProductSelect = (prodId) => {
    setSelectedProductId(prodId);
    const p = products.find((prod) => String(prod.id) === prodId);
    if (p) {
      const price = Number(p.selling_price);
      setUnitPrice(price);
      if (quantity && Number(quantity) > 0) {
        setPaymentAmount(Number((Number(quantity) * price).toFixed(2)));
      }
    }
  };

  // Quantity change handler that recalculates payment amount
  const handleQuantityChange = (val) => {
    const num = val === "" ? "" : Number(val);
    setQuantity(num);
    if (num && unitPrice) {
      setPaymentAmount(Number((num * Number(unitPrice)).toFixed(2)));
    }
  };

  // Unit price change handler
  const handleUnitPriceChange = (val) => {
    const num = val === "" ? "" : Number(val);
    setUnitPrice(num);
    if (quantity && num) {
      setPaymentAmount(Number((Number(quantity) * num).toFixed(2)));
    }
  };

  // Evaluate extraction confidence
  const matched = result?.product_match?.matched_product;
  const hasProduct = Boolean(matched && matched.id);
  const hasQuantity = Boolean(result?.quantity && Number(result.quantity) > 0);
  const isConfident = Boolean(
    hasProduct &&
    hasQuantity &&
    (Number(result?.confidence || 0) >= 0.70 || result?.status === "MATCHED")
  );

  const canConfirm = Boolean(
    selectedProductId &&
    quantity &&
    Number(quantity) > 0 &&
    paymentAmount &&
    Number(paymentAmount) > 0
  );

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1 text-xs font-bold px-2 py-0.5 rounded bg-primary-50 text-primary-700 border border-primary-200">
            <Sparkles className="w-3 h-3" />
            Voice-Powered Sales
          </span>
        </div>
        <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
          Voice Sale
        </h2>
        <p className="text-sm text-slate-500">
          Record what you sold hands-free. Speak naturally in English, Hindi, or everyday retail terms.
        </p>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-sm text-rose-800 flex items-start gap-3 animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1 font-medium leading-snug">{error}</div>
        </div>
      )}

      {/* SUCCESS CONFIRMATION RECEIPT */}
      {confirmedSale && (
        <div className="p-6 bg-emerald-50/80 border border-emerald-200 rounded-2xl shadow-sm space-y-4 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-emerald-950">
                Sale Recorded Successfully!
              </h3>
              <p className="text-xs text-emerald-700">
                Sale #{confirmedSale.sale_id} has been recorded and inventory stock has been updated.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-4 rounded-xl border border-emerald-100">
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Sale ID</div>
              <div className="text-lg font-black text-slate-900">#{confirmedSale.sale_id}</div>
            </div>
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Total Amount</div>
              <div className="text-lg font-black text-emerald-700">₹{confirmedSale.total_amount}</div>
            </div>
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Payment</div>
              <div className="text-sm font-bold text-slate-900">{confirmedSale.payment_status}</div>
            </div>
            <div>
              <div className="text-[11px] font-semibold text-slate-400 uppercase">Channel</div>
              <div className="text-sm font-bold text-indigo-700">Voice Assistant</div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={handleReset}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl transition-colors"
            >
              Record Another Sale
            </button>
          </div>
        </div>
      )}

      {/* AUDIO CAPTURE CARD */}
      {!confirmedSale && (
        <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-6">
          {/* Top Bar: Language Selector (English / Hindi) */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600">
              <Globe className="w-4 h-4 text-primary-600" />
              <span>Voice Speech Language:</span>
            </div>
            <div className="inline-flex p-0.5 bg-slate-100 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setVoiceLanguage("en")}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  voiceLanguage === "en"
                    ? "bg-white text-primary-700 shadow-sm"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                🇬🇧 English
              </button>
              <button
                type="button"
                onClick={() => setVoiceLanguage("hi")}
                className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  voiceLanguage === "hi"
                    ? "bg-white text-primary-700 shadow-sm"
                    : "text-slate-500 hover:text-slate-800"
                }`}
              >
                🇮🇳 हिंदी (Hindi)
              </button>
            </div>
          </div>

          <div className="flex flex-col items-center justify-center py-6 text-center space-y-4">
            {/* Status indicator pill */}
            <div className="mb-1">
              {recording ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                  Recording voice... ({recordingDuration}s)
                </span>
              ) : processing ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  <RefreshCw className="w-3 h-3 animate-spin" />
                  Processing sale...
                </span>
              ) : result ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <CheckCircle2 className="w-3 h-3" />
                  Review your sale details below
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-600">
                  Ready to record
                </span>
              )}
            </div>

            {/* Pulsing Mic Button */}
            <div className="relative">
              {recording && (
                <div className="absolute inset-0 rounded-full animate-pulse-ring" />
              )}
              <button
                type="button"
                onClick={recording ? stopRecording : startRecording}
                className={`relative z-10 w-24 h-24 rounded-full flex flex-col items-center justify-center shadow-lg transition-all transform active:scale-95 ${
                  recording
                    ? "bg-rose-600 hover:bg-rose-700 text-white ring-4 ring-rose-200"
                    : "bg-primary-600 hover:bg-primary-700 text-white hover:shadow-xl"
                }`}
              >
                {recording ? (
                  <>
                    <Square className="w-8 h-8 fill-current" />
                    <span className="text-[10px] font-bold mt-1 uppercase tracking-wider">
                      Stop ({recordingDuration}s)
                    </span>
                  </>
                ) : (
                  <>
                    <Mic className="w-8 h-8" />
                    <span className="text-[10px] font-bold mt-1 uppercase tracking-wider">
                      Tap to Speak
                    </span>
                  </>
                )}
              </button>
            </div>

            <div className="max-w-md">
              <p className="text-sm font-medium text-slate-700">
                {recording
                  ? "Speak now: Mention product name, quantity, amount, and payment mode."
                  : 'Speak naturally, e.g., "Sold 2 Maggi for 30 rupees cash"'}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Works with English, Hindi, and everyday retail expressions.
              </p>
            </div>

            {/* Audio File Selection / Drag-and-drop alternative */}
            <div className="pt-2 flex items-center gap-3">
              <input
                ref={fileInputRef}
                type="file"
                accept="audio/*,.m4a,.mp3,.wav,.ogg,.webm"
                onChange={handleFileChange}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-600 bg-slate-50 border border-slate-200 rounded-xl hover:bg-slate-100 transition-colors"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Audio File</span>
              </button>

              {(selectedFile || audioBlob) && !processing && (
                <button
                  type="button"
                  onClick={() => handleProcessAudio()}
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-primary-600 hover:bg-primary-700 rounded-xl shadow-sm transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Process Recording</span>
                </button>
              )}
            </div>

            {selectedFile && (
              <div className="inline-flex items-center gap-2 text-xs font-medium text-slate-600 bg-slate-100 px-3 py-1.5 rounded-lg">
                <FileAudio className="w-4 h-4 text-primary-600" />
                <span>Selected: {selectedFile.name}</span>
              </div>
            )}
            {audioBlob && !selectedFile && (
              <div className="inline-flex items-center gap-2 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg">
                <FileAudio className="w-4 h-4 text-emerald-600" />
                <span>Audio captured ready for processing</span>
              </div>
            )}

            {/* Quick Phrase Input / Tester */}
            <div className="w-full max-w-lg pt-4 border-t border-slate-100 flex flex-col items-center gap-2">
              <div className="text-[11px] font-semibold text-slate-400">
                Or enter / test sales phrase directly:
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleProcessText();
                }}
                className="flex items-center gap-2 w-full"
              >
                <input
                  type="text"
                  value={phraseInput}
                  onChange={(e) => setPhraseInput(e.target.value)}
                  placeholder='e.g., "sold 3 Maggie for Rs 45 in cash"'
                  className="flex-1 px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 bg-slate-50/70"
                />
                <button
                  type="submit"
                  disabled={processing || !phraseInput.trim()}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-primary-600 hover:bg-primary-700 disabled:opacity-50 rounded-xl transition-colors whitespace-nowrap shadow-sm"
                >
                  Analyze
                </button>
              </form>
              <div className="flex flex-wrap items-center justify-center gap-1.5 text-[10px] text-slate-400">
                <span className="font-medium">Quick test ({voiceLanguage === "hi" ? "हिंदी" : "English"}):</span>
                {voiceLanguage === "hi" ? (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setPhraseInput("मैगी के दो पैकेट बेचे 10 रुपये में।");
                        handleProcessText("मैगी के दो पैकेट बेचे 10 रुपये में।");
                      }}
                      className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors"
                    >
                      मैगी 2 पैकेट 10 रुपये
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPhraseInput("2 कोका कोला बेचे 30 रुपये नकद");
                        handleProcessText("2 कोका कोला बेचे 30 रुपये नकद");
                      }}
                      className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors"
                    >
                      2 कोका कोला 30 रुपये
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setPhraseInput("sold 3 Maggie for Rs 45 in cash");
                        handleProcessText("sold 3 Maggie for Rs 45 in cash");
                      }}
                      className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors"
                    >
                      3 Maggie Rs 45 cash
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPhraseInput("sold 2 Coca Cola for 30 rupees cash");
                        handleProcessText("sold 2 Coca Cola for 30 rupees cash");
                      }}
                      className="px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium transition-colors"
                    >
                      2 Coca Cola Rs 30 cash
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* PROCESSING STATE */}
          {processing && (
            <div className="p-8 bg-indigo-50/50 border border-indigo-100 rounded-2xl text-center space-y-3 animate-in fade-in">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 text-primary-700 animate-spin">
                <RefreshCw className="w-6 h-6" />
              </div>
              <h4 className="text-base font-bold text-slate-900">
                Processing your voice recording...
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Transcribing speech and automatically finding the matching product in your inventory catalog.
              </p>
            </div>
          )}

          {/* AI EXTRACTION RESULT */}
          {result && !processing && (
            <div className="border-t border-slate-100 pt-6 space-y-6">
              {/* Transcript Banner */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <div className="flex items-center justify-between mb-1">
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    Transcribed Speech
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsEditingTranscript(!isEditingTranscript);
                      setEditedTranscript(result.transcript || "");
                    }}
                    className="text-xs text-primary-600 hover:text-primary-700 font-medium inline-flex items-center gap-1"
                  >
                    <Edit3 className="w-3 h-3" />
                    {isEditingTranscript ? "Cancel" : "Edit Speech"}
                  </button>
                </div>
                {isEditingTranscript ? (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      handleProcessText(editedTranscript);
                    }}
                    className="flex items-center gap-2 mt-2"
                  >
                    <input
                      type="text"
                      value={editedTranscript}
                      onChange={(e) => setEditedTranscript(e.target.value)}
                      className="flex-1 px-3 py-1.5 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                    <button
                      type="submit"
                      disabled={processing || !editedTranscript.trim()}
                      className="px-3 py-1.5 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg shadow-sm"
                    >
                      Re-analyze
                    </button>
                  </form>
                ) : (
                  <div className="text-base font-semibold text-slate-900 italic">
                    "{result.transcript}"
                  </div>
                )}
              </div>

              {/* Extraction Metrics Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-white border border-slate-200 rounded-xl">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase">Intent</span>
                  <div className="text-sm font-bold text-slate-800 capitalize mt-0.5">
                    {result.intent || "Sale"}
                  </div>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-xl">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase">Detected Mode</span>
                  <div className="text-sm font-bold text-slate-800 capitalize mt-0.5">
                    {result.payment_mode || "Cash"}
                  </div>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-xl">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase">Confidence</span>
                  <div className="mt-1">
                    <ConfidenceMeter value={result.confidence} />
                  </div>
                </div>

                <div className="p-3 bg-white border border-slate-200 rounded-xl">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase">Match Status</span>
                  <div className="mt-1">
                    <StatusBadge status={isConfident ? "MATCHED" : (result.status || "REVIEW_REQUIRED")} size="xs" />
                  </div>
                </div>
              </div>

              {/* LOW CONFIDENCE ALERT (When AI couldn't confidently understand) */}
              {!isConfident && !manualEditMode && (
                <div className="p-6 bg-amber-50/80 border border-amber-200 rounded-2xl shadow-sm space-y-4 animate-in fade-in">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center flex-shrink-0 mt-0.5 shadow-sm">
                      <AlertCircle className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-amber-950">
                        RetailMind couldn't confidently understand this sale.
                      </h3>
                      <p className="text-xs text-amber-800 mt-0.5">
                        Some transaction details could not be detected with certainty from the speech. You can record again or complete the details manually.
                      </p>
                    </div>
                  </div>

                  {/* Detected vs Undetected Breakdown */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white p-4 rounded-xl border border-amber-100 text-xs">
                    <div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">Product</span>
                      <div className={`font-bold mt-0.5 ${hasProduct ? "text-emerald-700" : "text-amber-600"}`}>
                        {hasProduct ? matched.name : "Unmatched"}
                      </div>
                    </div>
                    <div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">Quantity</span>
                      <div className={`font-bold mt-0.5 ${hasQuantity ? "text-emerald-700" : "text-amber-600"}`}>
                        {hasQuantity ? `${result.quantity} units` : "Not clear"}
                      </div>
                    </div>
                    <div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">Payment Amount</span>
                      <div className={`font-bold mt-0.5 ${result.amount ? "text-slate-900" : "text-slate-400"}`}>
                        {result.amount ? `₹${result.amount}` : "Not detected"}
                      </div>
                    </div>
                    <div>
                      <span className="text-[10px] font-semibold text-slate-400 uppercase">Payment Mode</span>
                      <div className="font-bold text-slate-900 mt-0.5 capitalize">
                        {result.payment_mode || "Cash"}
                      </div>
                    </div>
                  </div>

                  {/* Action Choices */}
                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={handleReset}
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-amber-300 text-amber-900 hover:bg-amber-100 rounded-xl text-xs font-bold shadow-sm transition-colors"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Record Again</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setManualEditMode(true)}
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit Details Manually</span>
                    </button>
                  </div>
                </div>
              )}

              {/* REVIEW & CONFIRM SALE CARD (When confident OR user enters manual edit mode) */}
              {(isConfident || manualEditMode) && (
                <div className="p-5 bg-white border border-slate-200 rounded-xl shadow-sm space-y-4 animate-in fade-in">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">
                        Review & Confirm Sale
                      </h4>
                      <p className="text-xs text-slate-400">
                        {isConfident
                          ? "Automatically recognized from speech. Click confirm to record transaction."
                          : "Select the product and specify quantity/amount before confirming."}
                      </p>
                    </div>
                    {isConfident ? (
                      <span className="text-xs font-semibold px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        Ready to Confirm
                      </span>
                    ) : (
                      <span className="text-xs font-semibold px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-full flex items-center gap-1">
                        <Edit3 className="w-3 h-3" />
                        Manual Verification
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Inventory Product Selection */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Inventory Product
                      </label>
                      <select
                        value={selectedProductId}
                        onChange={(e) => handleProductSelect(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                      >
                        <option value="">-- Select Product --</option>
                        {products.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name} (Stock: {p.current_stock}, ₹{p.selling_price})
                          </option>
                        ))}
                      </select>
                      {matched && String(matched.id) === selectedProductId && (
                        <p className="text-[11px] text-emerald-600 mt-1 font-medium flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Matched: {matched.name} (₹{matched.selling_price || unitPrice})
                        </p>
                      )}
                    </div>

                    {/* Quantity Input */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Quantity Sold
                      </label>
                      <input
                        type="number"
                        min="1"
                        placeholder="e.g. 2"
                        value={quantity}
                        onChange={(e) => handleQuantityChange(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                      <p className="text-[11px] text-slate-400 mt-1">
                        {hasQuantity ? `Extracted: ${result.quantity} units` : "Enter quantity sold"}
                      </p>
                    </div>

                    {/* Unit Selling Price */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Unit Selling Price (₹)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        placeholder="e.g. 15.00"
                        value={unitPrice}
                        onChange={(e) => handleUnitPriceChange(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                    </div>

                    {/* Total Payment Amount */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Payment Amount Collected (₹)
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        placeholder="e.g. 30.00"
                        value={paymentAmount}
                        onChange={(e) => setPaymentAmount(e.target.value === "" ? "" : Number(e.target.value))}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                      />
                      <p className="text-[11px] text-slate-400 mt-1">
                        {quantity && unitPrice ? `Line total: ₹${(Number(quantity) * Number(unitPrice)).toFixed(2)}` : "Enter amount collected"}
                      </p>
                    </div>

                    {/* Payment Mode */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Payment Mode
                      </label>
                      <select
                        value={paymentMode}
                        onChange={(e) => setPaymentMode(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary-500"
                      >
                        <option value="CASH">Cash</option>
                        <option value="UPI">UPI / QR Code</option>
                        <option value="CREDIT">Customer Credit (Udhaar)</option>
                      </select>
                    </div>
                  </div>

                  {/* Primary Confirmation Action */}
                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={handleReset}
                      className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                    >
                      Discard
                    </button>

                    <button
                      type="button"
                      onClick={handleConfirmSale}
                      disabled={confirming || !canConfirm}
                      className="px-6 py-2.5 bg-primary-600 hover:bg-primary-700 active:bg-primary-800 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      {confirming ? (
                        <>
                          <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          <span>Saving Sale...</span>
                        </>
                      ) : (
                        <>
                          <span>
                            {canConfirm
                              ? `Confirm Sale (₹${Number(paymentAmount).toFixed(2)})`
                              : "Select Product & Details to Confirm"}
                          </span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default VoiceSale;
