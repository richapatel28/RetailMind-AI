const pool = require("../config/db");

const createCustomer = async (req, res) => {
  try {
    const { name, contact } = req.body;

    if (!name) {
      return res.status(400).json({
        message: "Customer name is required"
      });
    }

    const result = await pool.query(
      `INSERT INTO customers (name, contact)
       VALUES ($1, $2)
       RETURNING *`,
      [name, contact]
    );

    res.status(201).json({
      message: "Customer created successfully",
      customer: result.rows[0]
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to create customer"
    });
  }
};


const getCustomers = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT *
       FROM customers
       ORDER BY id DESC`
    );

    res.json(result.rows);

  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to fetch customers"
    });
  }
};


const getCustomer = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT *
       FROM customers
       WHERE id = $1`,
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "Customer not found"
      });
    }

    res.json(result.rows[0]);

  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to fetch customer"
    });
  }
};


module.exports = {
  createCustomer,
  getCustomers,
  getCustomer
};