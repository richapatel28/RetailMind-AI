from fastapi import APIRouter, HTTPException

from app.models.matching_models import ProductMatchRequest
from app.services.product_matcher import match_product


router = APIRouter(
    prefix="/ai/product",
    tags=["Product Matching"]
)


@router.post("/match")
def product_match(request: ProductMatchRequest):

    if not request.product_name.strip():

        raise HTTPException(
            status_code=400,
            detail="Product name is required"
        )


    result = match_product(
        request.product_name
    )


    return result