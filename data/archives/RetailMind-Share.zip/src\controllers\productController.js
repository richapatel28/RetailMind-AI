const pool = require("../config/db");

// CREATE PRODUCT
const createProduct = async (req, res) => {
  try {
    const {
      sku,
      name,
      aliases = [],
      unit = "pcs",
      selling_price,
      cost_price = 0,
      current_stock = 0,
      reorder_level = 0
    } = req.body;

    if (!name || selling_price === undefined) {
      return res.status(400).json({
        message: "Product name and selling price are required"
      });
    }

    const result = await pool.query(
      `INSERT INTO products
       (sku, name, aliases, unit, selling_price, cost_price,
        current_stock, reorder_level)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`,
      [
        sku,
        name,
        aliases,
        unit,
        selling_price,
        cost_price,
        current_stock,
        reorder_level
      ]
    );

    res.status(201).json({
      message: "Product created successfully",
      product: result.rows[0]
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to create product"
    });
  }
};


// GET ALL PRODUCTS
const getProducts = async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT *
       FROM products
       ORDER BY id DESC`
    );

    res.json(result.rows);

  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to fetch products"
    });
  }
};


// GET ONE PRODUCT
const getProduct = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      `SELECT *
       FROM products
       WHERE id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "Product not found"
      });
    }

    res.json(result.rows[0]);

  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to fetch product"
    });
  }
};


// UPDATE PRODUCT
const updateProduct = async (req, res) => {
  try {
    const { id } = req.params;

    const {
      sku,
      name,
      aliases,
      unit,
      selling_price,
      cost_price,
      reorder_level
    } = req.body;

    const result = await pool.query(
      `UPDATE products
       SET sku = $1,
           name = $2,
           aliases = $3,
           unit = $4,
           selling_price = $5,
           cost_price = $6,
           reorder_level = $7
       WHERE id = $8
       RETURNING *`,
      [
        sku,
        name,
        aliases,
        unit,
        selling_price,
        cost_price,
        reorder_level,
        id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        message: "Product not found"
      });
    }

    res.json({
      message: "Product updated successfully",
      product: result.rows[0]
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      message: "Failed to update product"
    });
  }
};


module.exports = {
  createProduct,
  getProducts,
  getProduct,
  updateProduct
};