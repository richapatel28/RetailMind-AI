import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, Mic, ShieldCheck, Zap } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export const Navbar = ({ onOpenSidebar }) => {
  const location = useLocation();
  const { user } = useAuth();

  const getPageMeta = () => {
    switch (location.pathname) {
      case "/dashboard":
        return { title: "Store Overview", subtitle: "Real-time sales, inventory, and quick actions" };
      case "/voice-sale":
        return { title: "Voice Sales", subtitle: "Record spoken sales in seconds" };
      case "/invoice":
        return { title: "Supplier Invoices", subtitle: "Upload bills to update inventory automatically" };
      case "/reconciliation":
        return { title: "Payment Reconciliation", subtitle: "Match bank transactions with your store records" };
      case "/product-matching":
        return { title: "Product Matching", subtitle: "Find products even with misspelled or partial names" };
      case "/inventory":
        return { title: "Products & Stock", subtitle: "View current stock levels and retail pricing" };
      default:
        return { title: "RetailMind AI", subtitle: "Intelligent Retail. Simplified." };
    }
  };

  const meta = getPageMeta();

  return (
    <header className="h-16 bg-white/90 backdrop-blur border-b border-slate-200 sticky top-0 z-30 flex items-center justify-between px-4 sm:px-6 lg:px-8">
      {/* Left: Mobile Toggle & Page Title */}
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenSidebar}
          className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg lg:hidden"
          title="Open Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div>
          <h1 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">
            {meta.title}
          </h1>
          <p className="text-xs text-slate-400 hidden sm:block">
            {meta.subtitle}
          </p>
        </div>
      </div>

      {/* Right: System Status & Action */}
      <div className="flex items-center gap-3">
        {/* Real-time Status Badge */}
        <div className="hidden md:flex items-center gap-2 px-2.5 py-1 bg-emerald-50 border border-emerald-200 rounded-full text-xs font-medium text-emerald-700">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>RetailMind AI Ready</span>
        </div>

        {/* Quick Voice Sale CTA */}
        {location.pathname !== "/voice-sale" && (
          <Link
            to="/voice-sale"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-primary-600 hover:bg-primary-700 text-white shadow-sm transition-all"
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Voice Sale</span>
          </Link>
        )}
      </div>
    </header>
  );
};

export default Navbar;
