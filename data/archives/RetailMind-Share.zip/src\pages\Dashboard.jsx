import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  TrendingUp,
  DollarSign,
  Package,
  CreditCard,
  Mic,
  FileText,
  Search,
  ArrowUpRight,
  AlertTriangle,
  RefreshCw,
  Sparkles,
  ShoppingBag
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { getDashboardData } from "../services/dashboardApi";
import StatusBadge from "../components/StatusBadge";

export const Dashboard = () => {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getDashboardData();
      setData(res);
    } catch (err) {
      console.error("Dashboard fetch error:", err);
      setError("Failed to load dashboard data. Ensure backend is running.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const todaySales = data?.analytics?.today_sales || 0;
  const todayProfit = data?.analytics?.today_profit || 0;
  const lowStockCount = data?.analytics?.low_stock_products || 0;
  const productsCount = data?.productsCount || 0;
  const recentSales = data?.recentSales || [];

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Good day, {user?.name || "Retailer"} 👋
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Here's what's happening with your store today.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchData}
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-sm disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-sm text-rose-800 flex items-center justify-between">
          <span>{error}</span>
          <button onClick={fetchData} className="underline font-semibold text-xs">
            Retry
          </button>
        </div>
      )}

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Card 1: Sales */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group hover:border-primary-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Today's Sales
            </span>
            <div className="w-9 h-9 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-black text-slate-900">
              ₹{Number(todaySales).toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 text-xs mt-1">
              <span className={`font-semibold inline-flex items-center ${Number(todayProfit) >= 0 ? "text-emerald-600" : "text-rose-600"}`}>
                <TrendingUp className="w-3.5 h-3.5 mr-0.5" />
                Profit: ₹{Number(todayProfit).toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Card 2: Inventory */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group hover:border-primary-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Active Catalog
            </span>
            <div className="w-9 h-9 rounded-xl bg-accent-50 text-accent-600 flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-black text-slate-900">
              {productsCount} <span className="text-sm font-medium text-slate-400">Products</span>
            </div>
            <div className="text-xs text-slate-500 mt-1">
              {lowStockCount > 0 ? (
                <span className="text-amber-600 font-semibold inline-flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  {lowStockCount} Low stock alerts
                </span>
              ) : (
                <span className="text-emerald-600 font-semibold">Stock healthy</span>
              )}
            </div>
          </div>
        </div>

        {/* Card 3: Store Assistant Status */}
        <div className="p-5 bg-gradient-to-br from-primary-900 to-indigo-950 text-white rounded-2xl shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-primary-200 uppercase tracking-wider">
              Store Automation
            </span>
            <div className="w-9 h-9 rounded-xl bg-white/10 text-emerald-300 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-lg font-bold text-white flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Smart Assistant Ready
            </div>
            <div className="text-xs text-slate-300 mt-1">
              Voice, Invoices & Reconciliation Active
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Hub */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Quick Actions
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Action 1: Voice Sale */}
          <Link
            to="/voice-sale"
            className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-primary-500 hover:shadow-md transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <Mic className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-base">Voice Sale</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Record customer sales instantly by speaking naturally in English or Hindi.
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1 text-xs font-bold text-primary-600 group-hover:translate-x-1 transition-transform">
              <span>Start recording</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </div>
          </Link>

          {/* Action 2: Upload Invoice */}
          <Link
            to="/invoice"
            className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-primary-500 hover:shadow-md transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <FileText className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-base">Supplier Invoices</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Upload supplier bills to verify prices and add new stock to inventory.
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1 text-xs font-bold text-primary-600 group-hover:translate-x-1 transition-transform">
              <span>Upload invoice</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </div>
          </Link>

          {/* Action 3: Reconcile Payments */}
          <Link
            to="/reconciliation"
            className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-primary-500 hover:shadow-md transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <CreditCard className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-base">Payment Reconciliation</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Match bank statements against store sales to catch discrepancies.
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1 text-xs font-bold text-primary-600 group-hover:translate-x-1 transition-transform">
              <span>Review payments</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </div>
          </Link>

          {/* Action 4: Product Matching */}
          <Link
            to="/product-matching"
            className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-primary-500 hover:shadow-md transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="w-10 h-10 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <Search className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-base">Product Matching</h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Match informal names, slang, and misspelled items to your catalog.
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1 text-xs font-bold text-primary-600 group-hover:translate-x-1 transition-transform">
              <span>Find product</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </div>
          </Link>
        </div>
      </div>

      {/* Recent Activity Table */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Recent Sales Activity</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Live transactions recorded across your store channels.
            </p>
          </div>
          <Link
            to="/voice-sale"
            className="text-xs font-semibold text-primary-600 hover:text-primary-700"
          >
            + New Voice Sale
          </Link>
        </div>

        {recentSales.length === 0 ? (
          <div className="py-12 text-center">
            <ShoppingBag className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-600">No transactions recorded yet today</p>
            <p className="text-xs text-slate-400 mt-1">
              Use Voice Sale to record your first transaction.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider border-y border-slate-100">
                <tr>
                  <th className="px-4 py-3">Sale ID</th>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Channel / Source</th>
                  <th className="px-4 py-3">Total Amount</th>
                  <th className="px-4 py-3">Payment Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentSales.map((sale) => (
                  <tr key={sale.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3 font-semibold text-slate-900">#{sale.id}</td>
                    <td className="px-4 py-3 text-xs">
                      {new Date(sale.sale_date || Date.now()).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${
                          sale.input_source === "VOICE"
                            ? "bg-indigo-50 text-indigo-700 border border-indigo-200"
                            : sale.input_source === "INVOICE"
                            ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                            : "bg-slate-100 text-slate-700"
                        }`}
                      >
                        {sale.input_source || "MANUAL"}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-900">
                      ₹{Number(sale.total_amount).toFixed(2)}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={sale.payment_status} size="xs" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
