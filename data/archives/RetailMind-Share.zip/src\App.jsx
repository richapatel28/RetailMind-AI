import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { ToastProvider } from "./components/Toast";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import VoiceSale from "./pages/VoiceSale";
import Invoice from "./pages/Invoice";
import Reconciliation from "./pages/Reconciliation";
import ProductMatching from "./pages/ProductMatching";
import Inventory from "./pages/Inventory";

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <Routes>
            {/* Public Auth Routes */}
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            {/* Protected SaaS Layout */}
            <Route element={<Layout />}>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/voice-sale" element={<VoiceSale />} />
              <Route path="/invoice" element={<Invoice />} />
              <Route path="/reconciliation" element={<Reconciliation />} />
              <Route path="/product-matching" element={<ProductMatching />} />
              <Route path="/inventory" element={<Inventory />} />
            </Route>

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
