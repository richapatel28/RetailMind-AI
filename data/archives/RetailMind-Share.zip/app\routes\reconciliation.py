from fastapi import APIRouter, HTTPException

from app.models.reconciliation_models import (
    ReconciliationRequest,
    ReconciliationResponse
)

from app.services.reconciliation_matcher import (
    reconcile_transaction
)


router = APIRouter(
    prefix="/ai/reconciliation",
    tags=["Payment Reconciliation"]
)


@router.post(
    "/match",
    response_model=ReconciliationResponse
)
def match_payment(
    user_id: int,
    transaction: ReconciliationRequest
):
    try:

        result = reconcile_transaction(
            user_id=user_id,
            transaction_date=transaction.transaction_date,
            amount=transaction.amount,
            reference=transaction.reference,
            narration=transaction.narration,
            direction=transaction.direction
        )


        best_match = result.get(
            "best_match"
        )


        confidence = 0.0


        if best_match:
            confidence = float(
                best_match.get(
                    "confidence",
                    0.0
                )
            )


        return {
            "transaction": transaction,

            "candidates":
                result.get(
                    "candidates",
                    []
                ),

            "best_match":
                best_match,

            "confidence":
                confidence,

            "status":
                result.get(
                    "status",
                    "UNMATCHED"
                )
        }


    except Exception as error:

        print(
            "RECONCILIATION ERROR:",
            str(error)
        )

        raise HTTPException(
            status_code=500,
            detail=
                "Payment reconciliation failed"
        )