import os
import re
import shutil
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List

import joblib
import whisper

from app.services.product_matcher import match_product

logger = logging.getLogger(__name__)

# ============================================================
# 1. ENSURE FFMPEG FOR WHISPER AUDIO DECODING
# ============================================================

def ensure_ffmpeg_in_path():
    """Ensure ffmpeg executable is available in PATH for Whisper."""
    if shutil.which("ffmpeg"):
        return

    try:
        import imageio_ffmpeg
        ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
        ffmpeg_dir = os.path.dirname(ffmpeg_exe)
        target = os.path.join(ffmpeg_dir, "ffmpeg.exe")
        if not os.path.exists(target):
            shutil.copyfile(ffmpeg_exe, target)
        if ffmpeg_dir not in os.environ.get("PATH", ""):
            os.environ["PATH"] = ffmpeg_dir + os.pathsep + os.environ.get("PATH", "")
    except Exception as exc:
        logger.warning(f"Could not automatically configure ffmpeg from imageio_ffmpeg: {exc}")

ensure_ffmpeg_in_path()


# ============================================================
# 2. PATHS & ML MODEL ASSETS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_DIR = BASE_DIR / "ml_assets" / "voice"
INTENT_MODEL_PATH = MODEL_DIR / "intent_model.pkl"
PAYMENT_MODEL_PATH = MODEL_DIR / "payment_model.pkl"

_intent_model = None
_payment_model = None
_whisper_model = None

SUPPORTED_LANGUAGES = {
    "en": "English",
    "hi": "Hindi",
    "mr": "Marathi"
}


def get_intent_model():
    global _intent_model
    if _intent_model is None:
        if not INTENT_MODEL_PATH.exists():
            raise FileNotFoundError(f"Intent model not found at {INTENT_MODEL_PATH}")
        _intent_model = joblib.load(str(INTENT_MODEL_PATH))
    return _intent_model


def get_payment_model():
    global _payment_model
    if _payment_model is None:
        if not PAYMENT_MODEL_PATH.exists():
            raise FileNotFoundError(f"Payment model not found at {PAYMENT_MODEL_PATH}")
        _payment_model = joblib.load(str(PAYMENT_MODEL_PATH))
    return _payment_model


def get_whisper_model():
    global _whisper_model
    if _whisper_model is None:
        ensure_ffmpeg_in_path()
        logger.info("Loading Whisper 'small' model...")
        _whisper_model = whisper.load_model("small")
        logger.info("Whisper 'small' model loaded successfully.")
    return _whisper_model


# ============================================================
# 3. DICTIONARIES & VARIANTS (from friend's nlp.py)
# ============================================================

NUMBER_WORDS = {
    # English
    "zero": 0, "one": 1, "two": 2, "three": 3, "four": 4,
    "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
    "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19, "twenty": 20,
    "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90, "hundred": 100,
    # Hindi
    "एक": 1, "दो": 2, "तीन": 3, "चार": 4, "पांच": 5, "पाँच": 5,
    "छह": 6, "छः": 6, "सात": 7, "आठ": 8, "नौ": 9, "दस": 10,
    "ग्यारह": 11, "बारह": 12, "तेरह": 13, "चौदह": 14, "पंद्रह": 15,
    "सोलह": 16, "सत्रह": 17, "अठारह": 18, "उन्नीस": 19, "बीस": 20,
    "तीस": 30, "चालीस": 40, "पचास": 50, "साठ": 60, "सत्तर": 70, "अस्सी": 80, "नब्बे": 90, "सौ": 100,
    # Marathi
    "दोन": 2, "पाच": 5, "सहा": 6, "सात": 7, "आठ": 8, "नऊ": 9, "दहा": 10,
    "अकरा": 11, "बारा": 12, "तेरा": 13, "चौदा": 14, "पंधरा": 15,
    "सोळा": 16, "सतरा": 17, "अठरा": 18, "एकोणीस": 19, "वीस": 20,
    "तीस": 30, "चाळीस": 40, "पन्नास": 50, "साठ": 60, "सत्तर": 70, "ऐंशी": 80, "नव्वद": 90, "शंभर": 100,
}

NUMBER_VARIANTS = {
    # 5
    "पाज": "पाच",
    # 300
    "तींसो": "तीनशे",
    "तीनशी": "तीनशे",
    "तीन्शी": "तीनशे",
    "तीन्खे": "तीनशे",
}

PAYMENT_VARIANTS = {
    "cash": [
        "cash", "नकद", "नकत", "नकदी", "रोख", "रोकड", "रोक",
    ],
    "upi": [
        "upi", "google pay", "gpay", "phonepe", "paytm", "online",
    ],
    "credit": [
        "credit", "credit pe", "credit par", "udhaar", "उधार", "उधारी", "उधारीवर",
    ]
}


# ============================================================
# 4. NORMALIZATION & PREDICTION UTILITIES
# ============================================================

def normalize_text(text: str) -> str:
    if not text:
        return ""
    text = text.strip()
    return re.sub(r"\s+", " ", text)


def normalize_whisper_text(text: str) -> str:
    text = normalize_text(text)
    for wrong, correct in NUMBER_VARIANTS.items():
        text = text.replace(wrong, correct)
    text = text.replace("नकत", "नकद")
    text = text.replace("रोक", "रोख")
    return text


def predict_intent(text: str) -> tuple[str, float]:
    model = get_intent_model()
    prediction = model.predict([text])[0]
    probabilities = model.predict_proba([text])[0]
    confidence = float(max(probabilities))
    return str(prediction), confidence


def predict_payment(text: str) -> tuple[str, float]:
    text_lower = text.lower()
    for payment_mode, variants in PAYMENT_VARIANTS.items():
        for variant in variants:
            if variant.lower() in text_lower:
                return payment_mode, 1.0

    model = get_payment_model()
    prediction = model.predict([text])[0]
    probabilities = model.predict_proba([text])[0]
    confidence = float(max(probabilities))

    if confidence < 0.60:
        return "unknown", confidence

    return str(prediction), confidence


def extract_quantity(text: str) -> Optional[float]:
    text = normalize_whisper_text(text)
    amount_words = ["तीनशे", "तींसो", "तीनशी", "तीन्शी", "तीन्खे"]
    quantity_text = text
    for word in amount_words:
        quantity_text = quantity_text.replace(word, " ")

    # Strip currency expressions so amounts are never confused with quantity
    quantity_text = re.sub(r"₹\s*\d+(?:\.\d+)?", " ", quantity_text)
    quantity_text = re.sub(
        r"\d+(?:\.\d+)?\s*(?:rupees?|rs\.?|रुपये|रुपया|रुप्याना|रुप्यांनी|रूपये|रूपया|रु)",
        " ",
        quantity_text,
        flags=re.IGNORECASE
    )
    quantity_text = re.sub(
        r"(?:rupees?|rs\.?|रुपये|रुपया|रूपये|रु)\s*\d+(?:\.\d+)?",
        " ",
        quantity_text,
        flags=re.IGNORECASE
    )

    unit_pattern = (
        r"(?:"
        r"kg|kilo|kilos|kilogram|"
        r"litre|liter|litres|liters|"
        r"packet|packets|pack|"
        r"box|boxes|"
        r"bottle|bottles|"
        r"piece|pieces|pcs|"
        r"किलो|पैकेट|पॅकेट|बोतल|बॉटल|पीस"
        r")"
    )

    sorted_number_words = sorted(
        NUMBER_WORDS.items(),
        key=lambda item: len(item[0]),
        reverse=True
    )

    # 1. Number word + unit (e.g. "दो पैकेट", "two packets")
    for word, value in sorted_number_words:
        if re.search(r"(?<!\w)" + re.escape(word) + r"\s*" + unit_pattern, quantity_text, re.IGNORECASE):
            return float(value)

    # 2. Digit + unit (e.g. "2 packets", "5 kg")
    match = re.search(r"\b(\d+(?:\.\d+)?)\s*" + unit_pattern, quantity_text, re.IGNORECASE)
    if match:
        return float(match.group(1))

    # 3. Recognize speech homophone "to" or "too" when used as quantity after sold/sell (e.g. "Sold to Maggi")
    homophone = re.search(r"\b(?:sold|sell|sale)\s+(?:to|too)\b", text, re.IGNORECASE)
    if homophone:
        return 2.0

    # 4. Standalone digit (e.g. "Sold 2 Maggi")
    match = re.search(r"\b(\d+(?:\.\d+)?)\b", quantity_text)
    if match:
        return float(match.group(1))

    # 5. Standalone number word (e.g. "दो", "two", "five")
    for word, value in sorted_number_words:
        if re.search(r"(?<!\w)" + re.escape(word) + r"(?!\w)", quantity_text, re.IGNORECASE):
            return float(value)

    return None


def extract_amount(text: str) -> Optional[float]:
    patterns = [
        # Number followed by currency: "45 rupees", "45 rs", "45 ₹", "45 रुपये"
        r"(\d+(?:\.\d+)?)\s*(?:rupees?|rs\.?|₹|रुपये|रुपया|रुप्याना|रुप्यांनी|रूपये|रूपया|रूप्याना|रूप्यांनी)",
        # Currency followed by number: "Rs 45", "Rs. 45", "Rupees 45", "₹45", "₹ 45", "रुपये 45"
        r"(?:rupees?|rs\.?|₹|रुपये|रुपया|रूपये|रु)\s*(\d+(?:\.\d+)?)",
        # "for 45 in cash", "for 45 cash", "for Rs 45"
        r"\bfor\s+(?:rs\.?|rupees?|₹)?\s*(\d+(?:\.\d+)?)\s*(?:in\s+cash|by\s+cash|cash|in\s+upi|upi|credit|rupees?|rs\.?)?\b",
        # Standalone "₹ 45"
        r"₹\s*(\d+(?:\.\d+)?)",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return float(match.group(1))

    amount_words_300 = ["तीनशे", "तींसो", "तीनशी", "तीन्शी", "तीन्खे"]
    currency_context = [
        "रुप", "रुपये", "रुपय", "रुप्याना", "रुप्यांनी",
        "रूप", "रूपये", "रूपय", "रूप्याना", "रूप्यांनी",
        "rupee", "rupees", "rs", "₹",
    ]

    has_300_word = any(word in text for word in amount_words_300)
    has_currency = any(word in text for word in currency_context)

    if has_300_word and has_currency:
        return 300.0

    return None


def extract_product(text: str) -> Optional[str]:
    text = normalize_whisper_text(text)
    # Strip currency expressions
    text = re.sub(r"₹\s*\d+(?:\.\d+)?", " ", text)
    text = re.sub(
        r"\d+(?:\.\d+)?\s*(?:rupees?|rs\.?|रुपये|रुपया|रुप्याना|रुप्यांनी|रूपये|रूपया|रु)",
        " ",
        text,
        flags=re.IGNORECASE
    )
    text = re.sub(
        r"(?:rupees?|rs\.?|रुपये|रुपया|रूपये|रु)\s*\d+(?:\.\d+)?",
        " ",
        text,
        flags=re.IGNORECASE
    )
    text = re.sub(r"\b\d+(?:\.\d+)?\b", " ", text)

    # Strip units (English & Hindi)
    units = [
        "kg", "kilo", "kilos", "kilogram", "litre", "liter", "litres", "liters",
        "packet", "packets", "pack", "box", "boxes", "bottle", "bottles",
        "piece", "pieces", "pcs", "unit", "units", "किलो", "पैकेट", "पॅकेट", "बोतल", "बॉटल", "पीस"
    ]
    for unit in units:
        text = re.sub(r"(?<!\w)" + re.escape(unit) + r"(?!\w)", " ", text, flags=re.IGNORECASE)

    # Strip number words
    sorted_number_words = sorted(NUMBER_WORDS.keys(), key=len, reverse=True)
    for word in sorted_number_words:
        text = re.sub(r"(?<!\w)" + re.escape(word) + r"(?!\w)", " ", text, flags=re.IGNORECASE)

    amount_words = ["तीनशे", "तींसो", "तीनशी", "तीन्शी", "तीन्खे"]
    for word in amount_words:
        text = text.replace(word, " ")

    stop_words = [
        "sold", "sell", "sale", "bought", "buy", "purchase", "purchased",
        "returned", "return", "cash", "upi", "credit", "for", "through",
        "using", "to", "on", "of", "the", "and", "by", "via", "with", "at", "per",
        "in", "into", "from", "a", "an", "is", "are", "was", "were",
        "worth", "amount", "cost", "total",
        "rupees", "rupee", "rs", "inr",
        "maine", "मैंने", "मैने", "में", "से", "को", "पे", "पर",
        "बेचे", "बेची", "बेचा", "बेच", "खरीदे", "खरीदी", "खरीदा", "खरीद",
        "वापस", "किया", "किए", "नकद", "नकत", "उधार",
        "विकली", "विकला", "विकले", "खरेदी", "केला", "केले", "परत", "रोख", "रोकड",
        "रुप्याना", "रुप्यांनी", "रुपये", "रूप्याना", "रूप्यांनी", "रूपये"
    ]

    # Sort stop words with longer forms before stems
    for word in sorted(stop_words, key=len, reverse=True):
        text = re.sub(r"(?<!\w)" + re.escape(word) + r"(?!\w)", " ", text, flags=re.IGNORECASE)

    # Clean punctuation including Hindi purnaviram (।)
    text = re.sub(r"[।.,!?:;\"'()\[\]{}]", " ", text)
    # Clean orphan Devanagari vowel signs (not preceded by a Devanagari consonant)
    text = re.sub(r"(?<![\u0904-\u0939])[\u093e-\u094f\u0962\u0963]+", " ", text)

    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return None

    ignored = {
        "में", "से", "को", "पे", "पर", "ना", "ने", "ही", "का", "के", "की", "तो", "भी",
        "in", "of", "for", "a", "an", "the", "to", "by", "is", "at", "per", "on", "with"
    }
    words = [w for w in text.split() if w not in ignored]

    if not words:
        return None

    # Preserve the full product phrase (e.g., "Surf Excel", "Tata Salt", "मैगी")
    product_phrase = " ".join(words).strip(".,!?;:")
    return product_phrase if product_phrase else None


def extract_customer(text: str) -> Optional[str]:
    # English: "Sold 2 Maggi to Rahul" - "to" must not be immediately following "sold" (which is quantity "to/2")
    if not re.search(r"\b(?:sold|sell|sale)\s+to\b", text, re.IGNORECASE):
        match = re.search(r"\bto\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)", text)
        if match:
            return match.group(1)

    # Hindi / Marathi: "Rahul ko", "Rahul को", "Rahul ला"
    match = re.search(r"\b([A-Z][a-z]+)\s+(?:ko|को|ला|ना)\b", text)
    if match:
        return match.group(1)

    return None


def calculate_confidence(
    intent_confidence: float,
    payment_confidence: float,
    product: Optional[str],
    quantity: Optional[float]
) -> float:
    if not product or quantity is None:
        # Cannot be confident about a sale without identifying both product and quantity
        score = float(intent_confidence) * 0.20 + float(payment_confidence) * 0.15
        if product:
            score += 0.10
        if quantity is not None:
            score += 0.10
        return float(round(min(score, 0.40), 2))

    score = float(intent_confidence) * 0.35 + float(payment_confidence) * 0.15 + 0.30 + 0.20
    return float(round(min(score, 1.0), 2))


def validate_transaction(data: Dict[str, Any]) -> Dict[str, Any]:
    errors = []
    if "error" in data:
        return {"valid": False, "errors": [data["error"]]}

    if data.get("intent") == "unknown":
        errors.append("Transaction type could not be identified")

    if data.get("intent") in ["sale", "purchase"]:
        if not data.get("product_text"):
            errors.append("Product not identified")
        if not data.get("quantity"):
            errors.append("Quantity not identified")

    if data.get("amount") is not None:
        if data["amount"] <= 0:
            errors.append("Invalid amount")

    return {
        "valid": len(errors) == 0,
        "errors": errors
    }


# ============================================================
# 5. HIGH LEVEL PIPELINE
# ============================================================

def transcribe_audio_file(audio_path: str, language: Optional[str] = None) -> Dict[str, str]:
    model = get_whisper_model()
    options = {
        "task": "transcribe",
        "fp16": False
    }
    if language and language in SUPPORTED_LANGUAGES:
        options["language"] = language

    result = model.transcribe(audio_path, **options)
    return {
        "text": result["text"].strip(),
        "whisper_language": result.get("language", "unknown")
    }


def parse_voice_text(raw_text: str, preferred_language: Optional[str] = None, whisper_lang: str = "en") -> Dict[str, Any]:
    """
    Parse voice text directly:
    1. Extract intent, product, quantity, amount, payment, customer
    2. Validate extracted fields
    3. Call Product Matcher for product_text
    4. Return structured response conforming to VoiceParseResponse
    """
    detected_lang = preferred_language if preferred_language else whisper_lang
    normalized_text = normalize_whisper_text(raw_text)

    # ML Classification
    intent, intent_conf = predict_intent(normalized_text)
    payment, payment_conf = predict_payment(normalized_text)

    # Information Extraction
    quantity = extract_quantity(normalized_text)
    amount = extract_amount(normalized_text)
    product_text = extract_product(normalized_text)
    customer = extract_customer(normalized_text)

    # Product matching using existing service
    product_match_summary = None
    if product_text:
        try:
            match_res = match_product(product_text)
            product_match_summary = match_res
        except Exception as exc:
            logger.error(f"Product matching failed for '{product_text}': {exc}")
            product_match_summary = {
                "input": product_text,
                "matched_product": None,
                "candidates": [],
                "confidence": 0.0,
                "status": "ERROR"
            }

    matched_product = product_match_summary.get("matched_product") if product_match_summary else None
    match_status = product_match_summary.get("status") if product_match_summary else "NO_MATCH"
    match_conf = float(product_match_summary.get("confidence", 0.0)) if product_match_summary else 0.0

    # Calculate realistic overall confidence reflecting product match & quantity
    if matched_product and match_status == "MATCHED" and quantity is not None and quantity > 0:
        # Both product and quantity are reliably identified!
        confidence = round(0.30 * intent_conf + 0.15 * payment_conf + 0.40 * match_conf + 0.15 * (1.0 if amount is not None else 0.85), 2)
        confidence = max(confidence, 0.90)
        status = "MATCHED"
    elif matched_product and quantity is None:
        # Product matched but quantity is missing
        confidence = min(0.55, round(0.35 * intent_conf + 0.15 * payment_conf + 0.35 * match_conf, 2))
        status = "REVIEW_REQUIRED"
    elif not matched_product or match_status == "NO_MATCH":
        # Product not matched
        confidence = min(0.40, round(0.20 * intent_conf + 0.20 * payment_conf, 2))
        status = "NO_MATCH"
    else:
        confidence = 0.30
        status = "REVIEW_REQUIRED"

    extraction_data = {
        "intent": intent,
        "product_text": product_text,
        "quantity": quantity,
        "amount": amount,
        "payment_mode": payment,
        "customer": customer,
        "language": detected_lang,
        "confidence": confidence
    }

    validation_result = validate_transaction(extraction_data)
    if not validation_result["valid"] and status == "MATCHED":
        status = "REVIEW_REQUIRED"

    return {
        "transcript": raw_text,
        "intent": intent,
        "product_text": product_text,
        "quantity": quantity,
        "amount": amount,
        "customer": customer,
        "payment_mode": payment,
        "language": detected_lang,
        "confidence": confidence,
        "status": status,
        "product_match": product_match_summary,
        "validation": validation_result
    }


def parse_voice_audio(audio_path: str, preferred_language: Optional[str] = None) -> Dict[str, Any]:
    """
    Full Voice pipeline:
    1. Transcribe audio with Whisper
    2. Delegate to parse_voice_text
    """
    transcription = transcribe_audio_file(audio_path, preferred_language)
    raw_text = transcription["text"]
    whisper_lang = transcription.get("whisper_language", "unknown")
    return parse_voice_text(raw_text, preferred_language, whisper_lang)
