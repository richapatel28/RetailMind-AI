from fastapi import FastAPI

from app.routes.product_matching import router as product_matching_router
from app.routes.reconciliation import router as reconciliation_router
from app.routes.voice import router as voice_router
from app.routes.invoice import router as invoice_router


app = FastAPI(
    title="RetailMind AI Service"
)


app.include_router(
    product_matching_router
)

app.include_router(
    reconciliation_router
)

app.include_router(
    voice_router
)

app.include_router(
    invoice_router
)


@app.get("/")
def root():

    return {
        "message": "RetailMind AI Service is running"
    }